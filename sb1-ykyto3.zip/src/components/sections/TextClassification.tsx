import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Progress } from '@/components/ui/progress';
import { Bot, User } from 'lucide-react';
import { toast } from 'sonner';

export function TextClassification() {
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{
    isAI: boolean;
    confidence: number;
  } | null>(null);

  const analyzeText = async () => {
    if (!text.trim()) {
      toast.error('Please enter some text to analyze');
      return;
    }

    setLoading(true);
    // Simulated API call
    setTimeout(() => {
      const confidence = Math.random() * 100;
      setResult({
        isAI: confidence > 50,
        confidence,
      });
      setLoading(false);
    }, 1500);
  };

  return (
    <div className="grid gap-6">
      <Card>
        <CardHeader>
          <CardTitle>Text Classification</CardTitle>
          <CardDescription>
            Analyze text to determine if it was written by a human or AI
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Textarea
            placeholder="Enter or paste text here..."
            className="min-h-[200px]"
            value={text}
            onChange={(e) => setText(e.target.value)}
          />
          <Button
            onClick={analyzeText}
            disabled={loading}
            className="w-full"
          >
            {loading ? 'Analyzing...' : 'Analyze Text'}
          </Button>
        </CardContent>
      </Card>

      {result && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {result.isAI ? (
                <>
                  <Bot className="h-5 w-5" />
                  <span>AI-Generated Content Detected</span>
                </>
              ) : (
                <>
                  <User className="h-5 w-5" />
                  <span>Human-Written Content Detected</span>
                </>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Confidence Score</span>
                <span>{result.confidence.toFixed(1)}%</span>
              </div>
              <Progress value={result.confidence} />
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}