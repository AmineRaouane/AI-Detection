import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ImageAnalysis } from '@/components/sections/ImageAnalysis';
import { AudioVerification } from '@/components/sections/AudioVerification';
import { VideoAuthentication } from '@/components/sections/VideoAuthentication';
import { TextClassification } from '@/components/sections/TextClassification';
import { ModeToggle } from '@/components/theme/mode-toggle';
import { ThemeProvider } from '@/components/theme/theme-provider';
import { Toaster } from '@/components/ui/sonner';
import { Brain } from 'lucide-react';

function App() {
  return (
    <ThemeProvider defaultTheme="dark" storageKey="vite-ui-theme">
      <div className="min-h-screen bg-background">
        <header className="border-b">
          <div className="w-full px-4 flex h-16 items-center">
            <div className="flex items-center space-x-2">
              <Brain className="h-6 w-6" />
              <h1 className="text-xl font-bold">AI Content Detective</h1>
            </div>
            <div className="ml-auto">
              <ModeToggle />
            </div>
          </div>
        </header>

        <main className="w-full px-4 py-6">
          <Tabs defaultValue="text" className="space-y-6">
            <TabsList className="grid w-full grid-cols-2 md:grid-cols-4">
              <TabsTrigger value="text">Text</TabsTrigger>
              <TabsTrigger value="image">Image</TabsTrigger>
              <TabsTrigger value="audio">Audio</TabsTrigger>
              <TabsTrigger value="video">Video</TabsTrigger>
            </TabsList>

            <TabsContent value="text" className="space-y-4">
              <TextClassification />
            </TabsContent>

            <TabsContent value="image" className="space-y-4">
              <ImageAnalysis />
            </TabsContent>

            <TabsContent value="audio" className="space-y-4">
              <AudioVerification />
            </TabsContent>

            <TabsContent value="video" className="space-y-4">
              <VideoAuthentication />
            </TabsContent>
          </Tabs>
        </main>
      </div>
      <Toaster />
    </ThemeProvider>
  );
}

export default App;